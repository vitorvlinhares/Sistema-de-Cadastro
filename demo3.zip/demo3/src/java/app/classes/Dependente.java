package app.classes;

public class Dependente {
    private String name;
    public Dependente(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

}
